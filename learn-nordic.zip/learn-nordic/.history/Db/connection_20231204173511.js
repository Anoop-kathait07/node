console.log("===========connection file===")
const mongoose = require('mongoose');

mongoose.connect('mongodb://localhost:27017/nordic-db',{
    useNewUrlParser: true,
    // useFindAndModify: false,
    useUnifiedTopology: true
})

const db = mongoose.connection;
db.once((open)=> console.log("Connected to database successfully"));
db.on((error)=>(console.error(error,"======================in ====")));