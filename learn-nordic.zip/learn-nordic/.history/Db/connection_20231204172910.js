const mongoose = require('mongoose');
console.log("===========connection file===")
mongoose.connect(process.env.DB,{
    useNewUrlParser: true,
    // useFindAndModify: false,
    useUnifiedTopology: true
})

const db = mongoose.connection;
db.once((open)=> console.log("Connected to database successfully"));
db.on((error)=>(console.error(error,"======================in ====")));