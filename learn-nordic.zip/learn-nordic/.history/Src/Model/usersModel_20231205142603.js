const mongoose = require('mongoose');

const usersSchema = mongoose.Schema({
    firstName:{type:String, required:true},

},{ timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' } })


module.exports = mongoose.model('users',usersSchema);