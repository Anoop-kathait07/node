
const statuses ={
    active : 'active',
    inActive : 'inActive'
}



module.exports ={
    statuses
}