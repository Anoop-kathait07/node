
const statuses ={
    active : 'active',
    inActive : 'inActive'
}

const usersTypes ={
    user:'user',
    admin:'admin'

}



module.exports ={
    statuses,
    usersTypes
}