
const statuses ={
    active : 'active',
    inActive : 'inActive'
}

const usersTypes ={
    user:"user",
    
}



module.exports ={
    statuses
}