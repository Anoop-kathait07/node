const { Validator } = require('node-input-validator');

module.exports.validate = async(data,fieldsToCheck)=>{
   const v =  new Validator(data, fieldsToCheck);
   const matched = await v.check();
   if (!matched) {
    ctx.status = 422;
    ctx.body = v.errors;
    return;
  }
}