const userModel = require("../../Model/usersModel")
const createNewUser = async(userData)=>{
    const userData = await userModel.create({
userData
    })
}