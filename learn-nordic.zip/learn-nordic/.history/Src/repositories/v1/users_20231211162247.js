const userModel = require("../../Model/usersModel");
const statusModel = require("../../Model/statusModel");
const userTypesModel = require("../../Model/userTypesModel");
const mongoose = require("mongoose")
const objectId = mongoose.Types.ObjectId;

const createNewUser = async (data) => {
    console.log("===========data==",data)
    return
  const userData = await userModel.create({
    data,
  });
  console.log("=========userData=====",userData)
  return userData 
};

const getStatuses = async(status)=>{
   const activeStatus =  await statusModel.findOne({
       name:status 
    })
    return activeStatus
}
const getUserTypes = async(usersType,statusId)=>{
    console.log("========usersType=======",usersType,"=====statusId=",statusId)
    const usersTypeData = await userTypesModel.findOne({
        // statusId:objectId(statusId),
        name:usersType
    })
    
    return usersTypeData;
}
module.exports={
    getStatuses ,
    createNewUser,
    getUserTypes
}