const userModel = require("../../Model/usersModel");
const createNewUser = async (userData) => {
  const userData = await userModel.create({
    userData,
  });
  console.log("=========userData=====",userData)
  return userData 
};
