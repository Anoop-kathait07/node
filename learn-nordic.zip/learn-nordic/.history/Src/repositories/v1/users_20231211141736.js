const userModel = require("../../Model/usersModel");
const userModel = require("../../Model/statusModel");
const createNewUser = async (userData) => {
  const userData = await userModel.create({
    userData,
  });
  console.log("=========userData=====",userData)
  return userData 
};

const getStatuses = async(status)=>{
   const activeStatus =  await getActiveStatus.findOne({
       name:status 
    })
    return activeStatus
}

module.exports={
    getStatuses 
}