const userModel = require("../../Model/usersModel");
const statusModel = require("../../Model/statusModel");
const createNewUser = async (data) => {
  const userData = await userModel.create({
    data,
  });
  console.log("=========userData=====",userData)
  return userData 
};

const getStatuses = async(status)=>{
   const activeStatus =  await statusModel.findOne({
       name:status 
    })
    return activeStatus
}

module.exports={
    getStatuses 
}