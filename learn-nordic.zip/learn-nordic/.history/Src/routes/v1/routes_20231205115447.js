const express = require("express");
const router = express.Router();
const {addUsers}= require("../../controller/v1/usersController")
console.log("============routes===")

/*Add user api*/
router.post("/users",addUsers)





module.exports = router;