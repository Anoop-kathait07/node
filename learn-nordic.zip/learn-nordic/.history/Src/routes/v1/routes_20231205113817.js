const express = express();
const router = express.router();
const {addUsers}= require("../../controller/v1/usersController")

/*Add user api*/
router.post("/users",addUsers)





module.exports = router;