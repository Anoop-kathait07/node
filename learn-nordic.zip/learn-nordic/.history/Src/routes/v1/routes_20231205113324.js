const express = express();
const router = express.router();

/*Add user api*/
router.post("/users",)





module.exports = router;