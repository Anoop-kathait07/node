const { validate } = require("../../helper/v1/validator")


const addUsers = async(req,res)=>{
    try {
        console.log("====================in add api ======")
        const validations ={
            name: "required|maxLength:100",
            email: "required|email|maxLength:255",
            password: "required|minLength:8|maxLength:45",
        }
        await validate(req.body,validations);
        
    } catch (error) {
        
    }
}


module.exports={
    addUsers,
}