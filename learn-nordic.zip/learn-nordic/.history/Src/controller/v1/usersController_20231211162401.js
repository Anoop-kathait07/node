const { validate } = require("../../helper/v1/validator");
const { statuses,usersTypes } = require("../../helper/v1/users");
const {getStatuses,createNewUser,getUserTypes} = require("../../repositories/v1/users")
const mongoose = require("mongoose")
const objectId = mongoose.Types.ObjectId;

const addUsers = async (req, res) => {
  try {
    const validations = {
      name: "required|maxLength:100",
      email: "required|email|maxLength:255",
      password: "required|minLength:8|maxLength:45",
      age: "required",
      gender: "required",
    };
    const { data, status } = await validate(req.body, validations);

    if (!status) {
     return res.status(422).json({ status: 1, message: "validation error", data });
    }
    console.log("==========1=")
    
    const {_id:statusId}= await getStatuses(statuses.active);
    console.log("======2=")
    const {_id:userTypeId}= await getUserTypes(usersTypes.user,statusId);
    console.log("========userTypeId=======",userTypeId)

    
   const {name,email,password,address,age,gender,mobile}= req.body
   console.log("=========geer=")
   const userData ={
    name,
    email,
    password,
    address,
    age:parseInt(age),
    gender:toLowerCase(gender) ,
    mobile:mobile,
    statusId :objectId(statusId),
    userTypeId:objectId(userTypeId),
   }
   console.log('======fsdfsdfsdf======',userData)

    await createNewUser(userData);
  } catch (error) {}
};

module.exports = {
  addUsers,
};
