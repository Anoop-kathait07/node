const { validate } = require("../../helper/v1/validator")


const addUsers = (req,res)=>{
    try {
        console.log("====================in add api ======")
        const validations ={

        }
        
    } catch (error) {
        
    }
}


module.exports={
    addUsers,
}