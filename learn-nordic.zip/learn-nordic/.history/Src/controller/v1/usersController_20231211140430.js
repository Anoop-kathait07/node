const { validate } = require("../../helper/v1/validator");

const addUsers = async (req, res) => {
  try {
    const validations = {
      name: "required|maxLength:100",
      email: "required|email|maxLength:255",
      password: "required|minLength:8|maxLength:45",
    };
    const { data, status } = await validate(req.body, validations);

    if (!status) {
      res.status(422).json({ status: 1, message: "validation error", data });
    }

   const {name,email,password}= req.body
   const userData ={
    name,
    email,
    password,
    address,
    age,
    gender,
    mobile
   }

    await createNewUser()
  } catch (error) {}
};

module.exports = {
  addUsers,
};
