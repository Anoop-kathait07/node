const { validate } = require("../../helper/v1/validator")


const addUsers = async(req,res)=>{
    try {
        console.log("====================in add api ======")
        const validations ={
            name: "required|maxLength:100",
            email: "required|email|maxLength:255",
            password: "required|minLength:8|maxLength:45",
        }
       const {status}=  await validate(req.body,validations);
       console.log("==========status==",status)
        
    } catch (error) {
        
    }
}


module.exports={
    addUsers,
}