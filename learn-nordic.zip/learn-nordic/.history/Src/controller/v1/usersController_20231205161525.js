const { validate } = require("../../helper/v1/validator")


const addUsers = async(req,res)=>{
    try {
       
        const validations ={
            name: "required|maxLength:100",
            email: "required|email|maxLength:255",
            password: "required|minLength:8|maxLength:45",
        }
       const {data,status}=  await validate(req.body,validations);
       console.log("==========status==",status)
       if(!status){
console.log("===============innn====")
res.status(422).json({status:1,message:"validation error", data})
       }
        
    } catch (error) {
        
    }
}


module.exports={
    addUsers,
}