const { validate } = require("../../helper/v1/validator");
const { statuses, usersTypes } = require("../../helper/v1/users");
const {
  getStatuses,
  createNewUser,
  getUserTypes,
} = require("../../repositories/v1/users");
const { imageUploadToS3 } = require("../../helper/v1/aws");
const mongoose = require("mongoose");
const objectId = mongoose.Types.ObjectId;
const bcrypt = require("bcrypt");
const saltRounds = 10;

const addUsers = async (req, res) => {
  try {
    const validations = {
      name: "required|maxLength:100",
      email: "required|email|maxLength:255",
      password: "required|minLength:8|maxLength:45",
      age: "required",
      gender: "required",
    };
    const { data, status } = await validate(req.body, validations);

    if (!status) {
      return res
        .status(422)
        .json({ status: 1, message: "validation error", data });
    }

    const { _id: statusId } = await getStatuses(statuses.active);

    const { _id: userTypeId } = await getUserTypes(usersTypes.user, statusId);

    const { name, email, password, address, age, gender, mobile } = req.body;
    let hashPassword = await bcrypt.hash(password, saltRounds);

    const userData = {
      name,
      email,
      password: hashPassword,
      address: address || "",
      age: parseInt(age),
      gender,
      mobile: mobile || "",
      statusId,
      userTypeId,
    };

    if (req.files) {
      console.log("========req.files=",req.files)
      const imageLocation = await imageUploadToS3(req.files.image.data ,process.env.AWS_S3_USERS_PHOTOS_FOLDER_NAME);
      console.log("======imageLocation=======", imageLocation);
      if (imageLocation) {
        console.log("=====imageLocation===1111====", imageLocation);
      
      } else {
        return res
          .status(400)
          .json({
            status: 1,
            message: "Some thing went wrong during upload image",
          });
      }
    }

    const createdUser = await createNewUser(userData);

    if (!createdUser) {
      return res
        .status(400)
        .json({ status: 1, message: "Some thing went wrong", data: null });
    }
    return res
      .status(200)
      .json({
        status: 1,
        message: "User created successfully",
        data: createdUser,
      });
  } catch (error) {}
};

module.exports = {
  addUsers,
};
