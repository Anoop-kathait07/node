
const addUsers = (req,res)=>{
    try {
        console.log("====================in add api ======")
        
    } catch (error) {
        
    }
}


module.exports={
    addUsers,
}