const addUsers = (req,res)=>{
    try {
        console.log("==================================innnnn======")
        
    } catch (error) {
        
    }
}


module.exports={
    addUsers
}