const dotenv = require('dotenv');
console.log("=================app.js==")
dotenv.config();
const express = require('express');
const app = express();
console.log("============here==")
require("./Db/connection")
const port = process.env.port

app.listen(port,console.log(` application listening at http://localhost:${port}`))
